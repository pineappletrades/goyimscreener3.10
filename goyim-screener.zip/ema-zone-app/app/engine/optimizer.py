"""'Find best settings' for the Strategy Test, with an honest out-of-sample check.

Trying many settings on the same history always finds something that looked great in hindsight (overfitting).
So the time span is split:
  search window  = the first 70% of the chosen period: settings are picked here only
  check window   = the last 30%, which the search never sees: the winner is re-run there
Both are shown next to SPY and QQQ bought and held over exactly the same days, plus the full span.
If the winner only shines in the search window, it was probably luck.

Search: one setting at a time (coordinate search, 2 passes): for each dimension try every value with the
others fixed, keep the best, move on. Each value needs at least `min_trades` trades in the search window.
Dimensions: lines alerted, stop loss, take profit, hold time, sector filter, each support signal,
macro filter, theme-rotation filter, debt limits. Entry rules (EMA lengths, fundamentals) stay as you set them.
"""
import math

import numpy as np

from . import strategy_bt as sbt

OBJECTIVES = {"cagr": "Highest yearly return", "calmar": "Best return for the risk (return ÷ worst drop)",
              "vs_qqq": "Beat QQQ by the most"}


def _stop(t, v=None):
    return next((s for s in sbt.STOP_GRID if s["type"] == t and float(s.get("value", 0) or 0) == float(v or 0)),
                {"type": t, "value": v})


def _tp(t, v=None):
    return next((s for s in sbt.TP_GRID if s["type"] == t and float(s.get("value", 0) or 0) == float(v or 0)),
                {"type": t, "value": v})


def dimensions(has_sector, has_support, has_macro, has_theme, has_debt):
    dims = [
        ("lines", "Lines alerted", [("both", "Both lines"), ("fast", "Fast line only"), ("slow", "Slow line only")]),
        ("stop", "Stop loss", [(_stop("none"), None)] + [(_stop("pct", v), None) for v in (7, 10, 15, 20)]
         + [(_stop("atr", 3), None), (_stop("slow", 3), None)] + [(_stop("trail", v), None) for v in (15, 20, 25)]),
        ("take_profit", "Take profit", [(_tp("none"), None)] + [(_tp("pct", v), None) for v in (20, 30, 50)] + [(_tp("atr", 8), None)]),
        ("hold_days", "Hold up to", [(63, "63 days"), (126, "126 days"), (252, "252 days")]),
    ]
    if has_sector:
        dims.append(("sector_filter", "Sector filter", [("off", "Any sector"), ("leading", "Leading only"),
                     ("leading_improving", "Leading or Improving"), ("not_lagging", "Anything but Lagging"),
                     ("undervalued", "Undervalued only"), ("not_overvalued", "Anything but Overvalued")]))
    if has_support:
        dims.append(("require", "Support signal required", [([], "None")] + [([k], lab) for k, lab in (
            ("light_pullback", "Pullback on light volume"), ("strong_close", "Closed strong at the line"),
            ("absorption", "Heavy volume, but it held"), ("accumulation", "Accumulation into the pullback"),
            ("respected", "Line held before"), ("no_repeat", "Skip if the line just failed"))]))
    if has_macro:
        dims.append(("macro_min", "Macro filter", [(None, "Any market"), (-2, "Not risk-off"), (0, "Neutral or better"), (3, "Risk-on only")]))
    if has_theme:
        dims.append(("theme_max_risk", "Theme rotation", [(None, "Ignore"), (3, "Block if all 3 warnings"), (2, "Block if 2+ warnings")]))
    if has_debt:
        dims.append(("debt", "Debt limit", [(None, "No debt limit"), ({"mcap": 50}, "Debt ≤ 50% of market cap"),
                     ({"de": 1.5}, "Debt-to-equity ≤ 1.5"), ({"mcap": 30, "de": 1.0}, "Debt ≤ 30% of cap and D/E ≤ 1"),
                     ({"rev": 100}, "Debt ≤ 100% of revenue")]))
    # attach labels for dict-valued options
    out = []
    for key, name, opts in dims:
        out.append((key, name, [(v, lab if lab is not None else (v.get("label") if isinstance(v, dict) else str(v))) for v, lab in opts]))
    return out


def label_of(dims, key, value):
    for k, _, opts in dims:
        if k == key:
            for v, lab in opts:
                if v == value:
                    return lab
    return str(value)


def apply_filters(alerts, cfg):
    from . import sector_filter as sf
    out = alerts
    if cfg.get("lines") in ("fast", "slow"):
        out = [a for a in out if a["line"] in (cfg["lines"], "both")]
    k = sf.key(cfg.get("sector_filter"))
    if k != "off":
        out = [a for a in out if sf.passes(k, a.get("sq"), a.get("sv"))]
    for r in cfg.get("require") or []:
        out = [a for a in out if (a.get("no_repeat") if r == "no_repeat" else (a.get("sig") or {}).get(r))]
    if cfg.get("macro_min") is not None:
        out = [a for a in out if a.get("macro") is not None and a["macro"] >= cfg["macro_min"]]
    if cfg.get("theme_max_risk") is not None:
        out = [a for a in out if a.get("theme_risk") is None or a["theme_risk"] < cfg["theme_max_risk"]]
    d = cfg.get("debt")
    if d:
        fin = ("Financials", "Real estate")
        keep = []
        for a in out:
            if a.get("sector") in fin:
                keep.append(a)
                continue
            if a.get("neg_eq"):
                continue
            if d.get("mcap") and a.get("debt_mcap") is not None and a["debt_mcap"] > d["mcap"]:
                continue
            if d.get("rev") and a.get("debt_rev") is not None and a["debt_rev"] > d["rev"]:
                continue
            if d.get("de") and a.get("debt_de") is not None and a["debt_de"] > d["de"]:
                continue
            keep.append(a)
        out = keep
    return out


def evaluate(alerts, cfg, fr, bench, start, end, slots):
    sel = [a for a in apply_filters(alerts, cfg) if start <= a["i"] < end]
    trades = sbt.run_trades(sel, fr, bench, cfg["stop"], int(cfg["hold_days"]), cfg["take_profit"])
    pf = sbt.portfolio(trades, fr, start, end, slots)
    done = [t for t in trades if t["exit_i"] < end and t["reason"] != "open"]
    st = sbt.trade_stats(done)
    return {"cagr": pf["cagr"], "maxdd": pf["maxdd"], "calmar": pf["calmar"], "total": pf["total"], "final": pf["final"],
            "taken": pf["taken"], "alerts": len(sel), "win": st.get("win"), "avg": st.get("avg"), "trades": st.get("n", 0)}


def _bh(series, start, end):
    s = series[start:end]
    s = s[~np.isnan(s)]
    if len(s) < 2:
        return None
    years = max(1e-9, len(s) / 252)
    eq = s / s[0]
    return {"cagr": sbt._r((eq[-1] ** (1 / years) - 1) * 100), "total": sbt._r((eq[-1] - 1) * 100),
            "maxdd": sbt._r(((eq / np.maximum.accumulate(eq)) - 1).min() * 100)}


def _score(m, objective, qqq_cagr, min_trades):
    if m["taken"] < min_trades or m["cagr"] is None:
        return -math.inf
    if objective == "calmar":
        return m["calmar"] if m["calmar"] is not None else (m["cagr"] if (m["maxdd"] or 0) >= 0 else -math.inf)
    if objective == "vs_qqq":
        return m["cagr"] - (qqq_cagr or 0)
    return m["cagr"]


def optimize(ds, p, status=None, objective="cagr", min_trades=20, split=0.7, passes=2, should_stop=lambda: False):
    st = status if status is not None else {}
    st.update(stage="Finding every past alert", done=0, total=0)
    base_p = dict(p, use_debt=False, sector_filter="off", require=[], macro_min=None, theme_max_risk=None)
    cal, fr, tickers, alerts, info = sbt.signals(ds, base_p)
    ps, period_label = sbt.period_start(cal, info["start_index"], p.get("period"))
    excl = {int(y) for y in (p.get("exclude_years") or [])}
    alerts = [a for a in alerts if a["i"] >= ps and int(str(cal[a["i"]])[:4]) not in excl]
    n = len(cal)
    cut = ps + int((n - ps) * split)
    bench = {}
    for b, _ in sbt.BENCHES:
        if b in ds["bars"]:
            bb = ds["bars"][b]
            pos = {d: k for k, d in enumerate(bb["d"].tolist())}
            bench[b] = np.array([bb["c"][pos[d]] if d in pos else np.nan for d in cal.tolist()], dtype="float64")
    slots = int(p.get("slots", 10))
    has = lambda key: any(a.get(key) is not None for a in alerts[:300])
    dims = dimensions(has("sq"), has("sig"), has("macro"), has("theme_risk"), has("debt_mcap") or has("debt_de"))
    d = p.get
    st0, tp0 = d("stop") or {"type": "none"}, d("take_profit") or {"type": "none"}
    start_cfg = {"lines": d("lines", "both"), "stop": _stop(st0["type"], st0.get("value")), "take_profit": _tp(tp0["type"], tp0.get("value")),
                 "hold_days": int(d("hold_days", 252)), "sector_filter": d("sector_filter", "off"), "require": list(d("require") or [])[:1],
                 "macro_min": d("macro_min"), "theme_max_risk": d("theme_max_risk"),
                 "debt": ({k2: v2 for k2, v2 in (("mcap", d("max_debt_mcap")), ("rev", d("max_debt_rev")), ("de", d("max_debt_equity"))) if v2}
                          if d("use_debt") else None)}
    bq = {b: _bh(bench[b], ps, cut) for b in bench}
    qqq_train = (bq.get("QQQ") or {}).get("cagr")
    total = passes * sum(len(o) for _, _, o in dims)
    st.update(stage="Searching settings (first 70% of the period)", total=total, done=0)
    cfg = dict(start_cfg)
    cur = evaluate(alerts, cfg, fr, bench, ps, cut, slots)
    cur_s = _score(cur, objective, qqq_train, min_trades)
    steps, k = [], 0
    for pas in range(passes):
        changed = False
        for key, name, opts in dims:
            if should_stop():
                break
            best_v, best_m, best_s = cfg.get(key), cur, cur_s
            for v, lab in opts:
                k += 1
                st.update(done=k, current=f"{name}: {lab}")
                m = evaluate(alerts, dict(cfg, **{key: v}), fr, bench, ps, cut, slots)
                s = _score(m, objective, qqq_train, min_trades)
                if s > best_s + 1e-9:
                    best_v, best_m, best_s = v, m, s
            if best_v != cfg.get(key):
                steps.append({"pass": pas + 1, "setting": name, "from": label_of(dims, key, cfg.get(key)),
                              "to": label_of(dims, key, best_v), "cagr_before": cur["cagr"], "cagr_after": best_m["cagr"],
                              "calmar_after": best_m["calmar"]})
                cfg[key], cur, cur_s, changed = best_v, best_m, best_s, True
        if not changed:
            break
    st.update(stage="Checking the winner on the last 30% it never saw")
    windows = {"search": (ps, cut), "check": (cut, n), "full": (ps, n)}
    res = {}
    for wname, (a0, a1) in windows.items():
        res[wname] = {"start": str(cal[a0]), "end": str(cal[a1 - 1]),
                      "best": evaluate(alerts, cfg, fr, bench, a0, a1, slots),
                      "yours": evaluate(alerts, start_cfg, fr, bench, a0, a1, slots),
                      "SPY": _bh(bench["SPY"], a0, a1) if "SPY" in bench else None,
                      "QQQ": _bh(bench["QQQ"], a0, a1) if "QQQ" in bench else None}
    chk = res["check"]
    beat_spy = chk["best"]["cagr"] is not None and chk["SPY"] and chk["best"]["cagr"] > (chk["SPY"]["cagr"] or 0)
    beat_qqq = chk["best"]["cagr"] is not None and chk["QQQ"] and chk["best"]["cagr"] > (chk["QQQ"]["cagr"] or 0)
    beat_yours = (chk["best"]["cagr"] or -1e9) >= (chk["yours"]["cagr"] or -1e9)
    if chk["best"]["taken"] < 5:
        verdict = "Too few trades in the check window to judge. Pick a longer period."
    elif beat_yours and beat_spy:
        verdict = "Held up: it also did better on the 30% of the period it never saw" + (" and beat QQQ there too." if beat_qqq else ", though not QQQ.")
    elif beat_yours:
        verdict = "Partly held up: better than your settings on the unseen 30%, but it didn't beat SPY there."
    else:
        verdict = "Didn't hold up: on the unseen 30% it did worse than your current settings, so the search window result was likely luck."
    return {"objective": objective, "objective_label": OBJECTIVES.get(objective, objective), "min_trades": min_trades,
            "period": period_label, "exclude_years": sorted(excl), "best": _jsonable_cfg(cfg), "yours": _jsonable_cfg(start_cfg),
            "best_labels": {name: label_of(dims, key, cfg.get(key)) for key, name, _ in dims},
            "your_labels": {name: label_of(dims, key, start_cfg.get(key)) for key, name, _ in dims},
            "steps": steps, "windows": res, "verdict": verdict, "evaluations": k}


def _jsonable_cfg(cfg):
    return {k: v for k, v in cfg.items()}


def to_params(cfg):
    """Optimizer settings -> Strategy Test params (so 'Use these settings' can re-run the full test)."""
    out = {"lines": cfg.get("lines", "both"), "stop": cfg.get("stop"), "take_profit": cfg.get("take_profit"),
           "hold_days": cfg.get("hold_days", 252), "sector_filter": cfg.get("sector_filter", "off"),
           "require": cfg.get("require") or [], "macro_min": cfg.get("macro_min"), "theme_max_risk": cfg.get("theme_max_risk")}
    d = cfg.get("debt")
    out["use_debt"] = bool(d)
    out["max_debt_mcap"] = (d or {}).get("mcap", 0)
    out["max_debt_rev"] = (d or {}).get("rev", 0)
    out["max_debt_equity"] = (d or {}).get("de", 0)
    return out
