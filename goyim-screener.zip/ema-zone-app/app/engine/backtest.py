"""Backtest: every time a stock pulled back to its 150/200 EMA, and what happened next.

Uses the same touch logic as the Investing strategy's "Pullback touches the fast or slow MA" rule:
  - uptrend: closed above BOTH lines on at least `above_days` of the prior 20 days
  - touch:   the day's low came within `tolerance`% above the line (and, if `hold`, closed at or above it)
  - each line is its own event; a new event needs `cooldown` days without a touch of that line
Also finds "zone" visits: the close sat between the two lines.

side="below" flips it to test the line as RESISTANCE: price had been closing below the line on at least
`above_days` of the prior 20 days, then the day's high came up within `tolerance`% of it (and, if `hold`,
closed at or below it). "Held" = the line did its job over the next `held_days` days: for support, no close
more than `held_pct`% below it; for resistance, no close more than `held_pct`% above it.

Daily bars only (Public gives 5 years of daily data). The first `slow` days are used to warm up the averages.
"""
import math

HORIZONS = [5, 20, 60, 120, 252]          # trading days: 1 week, 1 month, 3 months, 6 months, 1 year


def _ma(s, n, kind):
    return s.rolling(n).mean() if kind == "SMA" else s.ewm(span=n, adjust=False).mean()


def _r(x, d=2):
    return None if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))) else round(float(x), d)


def run(bars, fast=150, slow=200, kind="EMA", tolerance=0.5, above_days=15, hold=True, cooldown=10,
        mode="touch", stop_pct=None, side="above", held_pct=2.0, held_days=10, require=None):
    """mode: "touch" (low touched a line in an uptrend) | "zone" (close between the lines, any trend).
    side: "above" (pullbacks testing support) | "below" (rallies testing resistance) | "both"."""
    import pandas as pd

    if bars is None or len(bars) < slow + 30:
        raise ValueError(f"Need at least {slow + 30} days of daily prices (have {0 if bars is None else len(bars)})")
    c, lo, hi = bars["close"], bars["low"], bars["high"]
    f, s = _ma(c, fast, kind), _ma(c, slow, kind)
    warm = slow                                  # ignore the period where the averages are still settling
    tol = 1 + tolerance / 100
    above_both = (c > f) & (c > s)
    uptrend = above_both.shift(1).rolling(20).sum() >= above_days

    raw = {}
    if mode == "zone":
        top, bot = pd.concat([f, s], axis=1).max(axis=1), pd.concat([f, s], axis=1).min(axis=1)
        raw["zone"] = (c <= top) & (c >= bot)
    else:
        for key, line in (("fast", f), ("slow", s)):
            if side in ("above", "both"):
                t = lo <= line * tol
                if hold:
                    t &= c >= line
                raw[key] = t & uptrend
            if side in ("below", "both"):
                below_line = (c < line).shift(1).rolling(20).sum() >= above_days
                t = hi >= line / tol
                if hold:
                    t &= c <= line
                raw[key + "_r"] = t & below_line

    n = len(c)
    events = []
    for key, mask in raw.items():
        last = -10 ** 9
        vals = mask.values
        for i in range(warm, n):
            if not vals[i]:
                continue
            if i - last > cooldown:
                events.append((i, key))
            last = i                              # a run of touch days counts once
    events.sort()

    out = []
    cv, lv, hv = c.values, lo.values, hi.values
    fv, sv = f.values, s.values
    for i, key0 in events:
        entry = float(cv[i])
        res = key0.endswith("_r")
        key = key0[:-2] if res else key0
        line = fv[i] if key == "fast" else sv[i] if key == "slow" else None
        lser = fv if key == "fast" else sv if key == "slow" else None
        ev = {"date": c.index[i].strftime("%Y-%m-%d"), "i": int(i), "line": key, "side": "below" if res else "above",
              "price": _r(entry), "ma_fast": _r(fv[i]), "ma_slow": _r(sv[i]),
              "low": _r(lv[i]), "high": _r(hv[i]), "dist_line_pct": _r((entry / line - 1) * 100) if line else None,
              "returns": {}, "complete": {}}
        # did the line hold (support stayed support / resistance turned price back)?
        k = min(n, i + 1 + held_days)
        if lser is not None and k > i + 1 and i + held_days < n:
            if res:
                ev["held"] = not any(cv[x] > lser[x] * (1 + held_pct / 100) for x in range(i + 1, k))
            else:
                ev["held"] = not any(cv[x] < lser[x] * (1 - held_pct / 100) for x in range(i + 1, k))
        else:
            ev["held"] = None
        for h in HORIZONS:
            j = i + h
            if j < n:
                ev["returns"][str(h)] = _r((cv[j] / entry - 1) * 100)
                ev["complete"][str(h)] = True
            else:
                ev["returns"][str(h)] = None
        # worst drop and best gain over the next 60 trading days (intraday lows/highs)
        j = min(n, i + 61)
        if j > i + 1:
            ev["max_drop_60"] = _r((min(lv[i + 1:j]) / entry - 1) * 100)
            ev["max_gain_60"] = _r((max(hv[i + 1:j]) / entry - 1) * 100)
            # did it close more than 3% below the slow line within 20 days (the support "broke")?
            k = min(n, i + 21)
            ev["broke_slow_20"] = bool(any(cv[x] < sv[x] * 0.97 for x in range(i + 1, k)))
        else:
            ev["max_drop_60"] = ev["max_gain_60"] = None
            ev["broke_slow_20"] = None
        if stop_pct:
            stop = (line or entry) * (1 - stop_pct / 100)
            hit = next((x for x in range(i + 1, min(n, i + 253)) if lv[x] <= stop), None)
            ev["stopped_days"] = (hit - i) if hit else None
        out.append(ev)

    # support signals on each touch day (daily price + volume, past data only), and the line's record before it
    if mode != "zone" and "volume" in bars and len(out):
        from . import support
        hm = support.hist_masks(hi, lo, c, bars["volume"], {"held_pct": held_pct, "held_days": held_days})
        sp = support._p({"held_pct": held_pct, "held_days": held_days})
        for ev in out:
            i = ev["i"]
            prior = [x for x in out if x["line"] == ev["line"] and x["side"] == ev["side"] and x["i"] < i
                     and x.get("held") is not None and x["i"] + held_days < i]
            rate = 100 * sum(1 for x in prior if x["held"]) / len(prior) if prior else None
            ev["signals"] = {k: bool(hm[k][i, 0]) for k in ("light_pullback", "strong_close", "absorption", "accumulation")}
            ev["signals"]["respected"] = bool(len(prior) >= sp["respect_tests"] and rate is not None and rate >= sp["respect_rate"])
            ev["clv"] = _r(hm["clv"][i, 0] * 100, 0)
            ev["vol_ratio"] = _r(hm["vol_ratio"][i, 0], 2)
    signal_table = None
    if out and out[0].get("signals") is not None:
        from . import support
        signal_table = support.compare([{"signals": e_["signals"], "held": e_.get("held"), "ret": e_["returns"].get("20"),
                                         "r252": e_["returns"].get("252")} for e_ in out])
    req = [k for k in (require or []) if k]
    all_count = len(out)
    if req:
        out = [e_ for e_ in out if all((e_.get("signals") or {}).get(k) for k in req)]

    # baseline: buying on ANY day after warm-up, same horizons (what the touches are compared against)
    base = {}
    for h in HORIZONS:
        rets = [(cv[x + h] / cv[x] - 1) * 100 for x in range(warm, n - h)]
        base[str(h)] = _summ(rets)

    summary = {}
    groups = ["all", "fast", "slow", "zone"]
    if side == "both":
        groups += ["support", "resistance", "fast_support", "slow_support", "fast_resistance", "slow_resistance"]
    pick = {"support": lambda e: e["side"] == "above", "resistance": lambda e: e["side"] == "below"}
    for group in groups:
        if group == "all":
            evs = out
        elif group in pick:
            evs = [e for e in out if pick[group](e)]
        elif "_" in group:
            ln, sd = group.split("_")
            evs = [e for e in out if e["line"] == ln and e["side"] == ("above" if sd == "support" else "below")]
        else:
            evs = [e for e in out if e["line"] == group]
        if not evs:
            continue
        summary[group] = {
            "count": len(evs),
            "horizons": {str(h): _summ([e["returns"][str(h)] for e in evs if e["returns"][str(h)] is not None])
                         for h in HORIZONS},
            "avg_max_drop_60": _r(_mean([e["max_drop_60"] for e in evs if e["max_drop_60"] is not None])),
            "avg_max_gain_60": _r(_mean([e["max_gain_60"] for e in evs if e["max_gain_60"] is not None])),
            "broke_rate": _r(_pct([e["broke_slow_20"] for e in evs if e["broke_slow_20"] is not None])),
            "held_rate": _r(_pct([e["held"] for e in evs if e.get("held") is not None])),
            "held_n": sum(1 for e in evs if e.get("held") is not None),
        }

    step = max(1, (n - warm) // 900)            # thin the chart series to keep the page light
    idx = list(range(max(0, warm - 60), n, step))
    if idx[-1] != n - 1:
        idx.append(n - 1)
    chart = {"t": [c.index[x].strftime("%Y-%m-%d") for x in idx], "c": [_r(cv[x]) for x in idx],
             "f": [_r(fv[x]) for x in idx], "s": [_r(sv[x]) for x in idx]}
    return {"events": out, "summary": summary, "baseline": base, "chart": chart, "signal_table": signal_table,
            "require": req, "events_before_filter": all_count,
            "params": {"fast": fast, "slow": slow, "kind": kind, "tolerance": tolerance, "above_days": above_days,
                       "hold": hold, "cooldown": cooldown, "mode": mode, "side": side,
                       "held_pct": held_pct, "held_days": held_days},
            "period": {"start": c.index[warm].strftime("%Y-%m-%d"), "end": c.index[-1].strftime("%Y-%m-%d"),
                       "days": n - warm},
            "horizons": HORIZONS}


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def _pct(flags):
    return 100 * sum(1 for x in flags if x) / len(flags) if flags else None


def _summ(rets):
    rets = [r for r in rets if r is not None]
    if not rets:
        return {"n": 0, "win": None, "avg": None, "median": None, "best": None, "worst": None}
    srt = sorted(rets)
    m = len(srt)
    med = srt[m // 2] if m % 2 else (srt[m // 2 - 1] + srt[m // 2]) / 2
    return {"n": m, "win": _r(100 * sum(1 for r in rets if r > 0) / m, 1), "avg": _r(sum(rets) / m),
            "median": _r(med), "best": _r(srt[-1]), "worst": _r(srt[0])}


def level_history(bars, length, kind="EMA", side="above", tolerance=0.5, trend_days=15, held_pct=2.0, held_days=10):
    """How one line behaved in the past: every test from `side` and how often it held.
    -> {"tests", "held", "rate", "last": date, "avg_20d"} or None (not enough data)."""
    if bars is None or len(bars) < length + 40:
        return None
    r = run(bars, fast=length, slow=length, kind=kind, tolerance=tolerance, above_days=trend_days, hold=True,
            cooldown=10, side=side, held_pct=held_pct, held_days=held_days)
    evs = [e for e in r["events"] if e["line"] == "fast" and e.get("held") is not None]
    if not evs:
        return {"tests": 0, "held": 0, "rate": None, "side": side, "length": length, "kind": kind, "years": _r(r["period"]["days"] / 252, 1)}
    held = sum(1 for e in evs if e["held"])
    r20 = [e["returns"]["20"] for e in evs if e["returns"].get("20") is not None]
    return {"tests": len(evs), "held": held, "rate": _r(100 * held / len(evs), 0), "side": side, "length": length,
            "kind": kind, "last": evs[-1]["date"], "avg_20d": _r(_mean(r20)), "years": _r(r["period"]["days"] / 252, 1)}


def level_line(h):
    """'📊 EMA 200 as resistance: turned price back 7 of 9 times (78%) in 4.2 yrs · avg 20d after −3.1%'."""
    if not h:
        return ""
    role = "resistance" if h["side"] == "below" else "support"
    if not h["tests"]:
        return f"📊 {h['kind']} {h['length']} as {role}: no past tests in {h['years']} yrs"
    verb = "turned price back" if h["side"] == "below" else "held"
    grade = "strong" if h["rate"] >= 70 else "mixed" if h["rate"] >= 45 else "weak"
    tail = f" · avg 20d after {h['avg_20d']:+.1f}%" if h.get("avg_20d") is not None else ""
    return f"📊 {h['kind']} {h['length']} as {role} ({grade}): {verb} {h['held']} of {h['tests']} times ({h['rate']:.0f}%) in {h['years']} yrs{tail}"
